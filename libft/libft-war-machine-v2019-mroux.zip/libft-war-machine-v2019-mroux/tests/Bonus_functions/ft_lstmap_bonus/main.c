/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbaudet <hbaudet@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/28 15:16:21 by jtoty             #+#    #+#             */
/*   Updated: 2019/11/07 10:20:43 by mroux            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "../../../libft.h"
#include <unistd.h>
#include <string.h>
#include <stdio.h>

void	ft_print_result(t_list *elem)
{
	int		len;

	len = 0;
	while (((char *)elem->content)[len])
		len++;
	write(1, ((char *)elem->content), len);
	write(1, "\n", 1);
}

t_list	*ft_lstnewone(void const *content)
{
	t_list	*elem;

	elem = (t_list *)malloc(sizeof(t_list));
	if (!elem)
		return (NULL);
	if (!content)
	{
		elem->content = NULL;
	}
	else
	{
		if (!(elem->content = malloc(sizeof(*(elem->content)) * sizeof(elem->content))))
			return (NULL);
		elem->content = memcpy(elem->content, content, sizeof(elem->content));
	}
	elem->next = NULL;
	return (elem);
}

void	*ft_map(void *b)
{
	char	*tmp;
	int		i;
	char	*ptr;

	i = 0;
	ptr = (char *)b;
	tmp = ft_strdup(ptr);
	while (tmp[i])
	{
		tmp[i] += 1;
		i++;
	}
	return ((void *)tmp);
}

int main(int argc, const char *argv[])
{
	t_list		*elem;
	t_list		*elem2;
	t_list		*elem3;
	t_list		*elem4;
	t_list		*list;
	char		str [] = "lorem";
	char		str2 [] = "ipsum";
	char		str3 [] = "dolor";
	char		str4 [] = "sit";

	elem = ft_lstnew(ft_strdup(str));
	elem2 = ft_lstnew(ft_strdup(str2));
	elem3 = ft_lstnew(ft_strdup(str3));
	elem4 = ft_lstnew(ft_strdup(str4));
	alarm(5);
	if (argc == 1 || !elem || !elem2 || !elem3 || !elem4)
		return (0);
	elem->next = elem2;
	elem2->next = elem3;
	elem3->next = elem4;
	if (atoi(argv[1]) == 1)
	{
		if (!(list = ft_lstmap(elem, &ft_map, &free)))
			return (0);
		if (list == elem)
			write(1, "A new list is not returned\n", 27);
		int i;
		i = 0;
		ft_print_result(list);
		while (list->next)
		{
			list = list->next;
			ft_print_result(list);
			i++;
		}
	}
	return (0);
}
